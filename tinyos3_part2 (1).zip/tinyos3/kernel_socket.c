#include "tinyos.h"
#include "kernel_dev.h"
#include "kernel_socket.h"
#include "kernel_cc.h"


/*Socket read,write,close is basically the same with pipe read,write,close but we make some checks first*/
int socket_read(void* socket_cb_t, char *buf, unsigned int n) {
	socket_cb* peerR = (socket_cb*) socket_cb_t;
	if(peerR == NULL) return -1;
//check if read end is active and the socket is peer type
	if(peerR->peer_s.read_pipe == NULL || peerR->type != SOCKET_PEER) {
		return -1;
	}
	else{

		int i = pipe_read(peerR->peer_s.read_pipe,buf,n);
		return i;
	}
}

int socket_write(void* socket_cb_t, const char *buf, unsigned int n){
	socket_cb* peerW = (socket_cb*) socket_cb_t;
	if(peerW==NULL) return -1;

	if(peerW->peer_s.write_pipe == NULL || peerW->type != SOCKET_PEER){
		return -1;
	}
	else {
		int j = pipe_write(peerW->peer_s.write_pipe,buf,n);
		return j;
	}
}

int socket_close(void* socket_cb_t){

	socket_cb* cur_socket = (socket_cb*) socket_cb_t;
	if(cur_socket==NULL) return -1;

		if(cur_socket->type==SOCKET_LISTENER){
			PORT_MAP[cur_socket->port] = NULL;

			kernel_broadcast(&cur_socket->listener_s.req_available);
		}
		else if(cur_socket->type==SOCKET_PEER){
			if(cur_socket->peer_s.read_pipe!=NULL) { //closing the read end of the pipe of peer socket
				pipe_reader_close(cur_socket->peer_s.read_pipe);
			    cur_socket->peer_s.read_pipe=NULL;
			}
			
		     if(cur_socket->peer_s.write_pipe!=NULL) {
			    pipe_writer_close(cur_socket->peer_s.write_pipe);//closing the write end of the pipe of peer socket
			    cur_socket->peer_s.write_pipe=NULL;
		    }
	}
		cur_socket->refcount--;
		if(cur_socket->refcount==0) free(cur_socket);
		return 0;
}


file_ops socket_fileops={
	.Open = NULL,
	.Read = socket_read,
	.Write = socket_write,
	.Close = socket_close
};
//@port is the potition on PORT_MAP
Fid_t sys_Socket(port_t port)
{
	if(port>MAX_PORT || port<0) return NOFILE;

	FCB* fcb;
	Fid_t fid = 0;
	if(fid==NOFILE) return NOFILE;
	if(FCB_reserve(1,&fid,&fcb)==0) return NOFILE;

	socket_cb* socketCb = (socket_cb*)xmalloc(sizeof(socket_cb));

	socketCb->port = port;
	socketCb->refcount = 0;
	socketCb->fcb = fcb;
	socketCb->type = SOCKET_UNBOUND;

	fcb->streamfunc = &socket_fileops;
	fcb->streamobj = socketCb;

	return fid;
	
}

int sys_Listen(Fid_t sock)
{
	FCB* curr_fcb = get_fcb(sock);
	if(curr_fcb==NULL) return -1;

	if(sock==NOFILE) return -1;
	socket_cb* socket = (socket_cb*)curr_fcb->streamobj;

	if(socket==NULL || socket->port<0 || socket->port>MAX_PORT) return -1;

	if(PORT_MAP[socket->port] != NULL) return -1;

	if(socket->port==NOPORT ) return -1;

	if(socket->type!=SOCKET_UNBOUND) return -1;
    
    PORT_MAP[socket->port] = socket;
	socket->type = SOCKET_LISTENER;
	rlnode_init(&socket->listener_s.queue,NULL);
	socket->listener_s.req_available =COND_INIT;

	return 0;
}


Fid_t sys_Accept(Fid_t lsock)
{
	FCB* fcb = get_fcb(lsock);
	//check if legal
	if(fcb==NULL) return NOFILE;

	socket_cb* socket = (socket_cb*) fcb->streamobj;
	//check if socket is initialized
	if(socket==NULL || socket->port<0 || socket->port>MAX_PORT) return NOFILE;

	if(socket->type!=SOCKET_LISTENER) return NOFILE;

	socket->refcount++;
	//if noone is at queue make socket sleep
	while(is_rlist_empty(&socket->listener_s.queue) && socket->refcount!=0) {
		if(PORT_MAP[socket->port]==NULL) return NOFILE;
		kernel_wait(&socket->listener_s.req_available,SCHED_PIPE);
	}

    if(PORT_MAP[socket->port]==NULL) return NOFILE;
	//if list isn't empty get the first request 	
	rlnode* node = rlist_pop_front(&socket->listener_s.queue);
	connection_request* req= (connection_request*)node -> connection_request;
	//create the socket control block that made the request 
	socket_cb* peer1 = req->peer;
    if(peer1==NULL) return NOFILE;

	if(peer1->type!=SOCKET_UNBOUND) return NOFILE;

	Fid_t p1 = sys_Socket(peer1->port);
	
	FCB* f2 = get_fcb(p1);

	if(p1==NOFILE) return NOFILE;

	//make the second peer socket
	socket_cb* peer2 = (socket_cb*)f2->streamobj;

	if(peer2==NULL) return NOFILE;

	peer1->type = SOCKET_PEER;
	peer2->type = SOCKET_PEER;

//create the first pipe and make all the intitialization needed
	pipe_cb* curpipe1 = (pipe_cb*)xmalloc(sizeof(pipe_cb));
    
	curpipe1->writer = peer2->fcb;
	curpipe1->reader = peer1->fcb;
	curpipe1 ->has_space=COND_INIT;
    curpipe1 ->has_data=COND_INIT;
    curpipe1 ->w_pos=0;
    curpipe1 ->r_pos=0;

    
//create the second pipe and make all the intitialization needed

    pipe_cb* curpipe2 = (pipe_cb*)xmalloc(sizeof(pipe_cb));

    curpipe2->writer = peer1->fcb;
	curpipe2->reader = peer2->fcb;
	curpipe2 ->has_space=COND_INIT;
    curpipe2 ->has_data=COND_INIT;
    curpipe2 ->w_pos=0;
    curpipe2 ->r_pos=0;

  

    peer1->peer_s.peer = peer2;
    peer1->peer_s.read_pipe = curpipe1;
    peer1->peer_s.write_pipe = curpipe2;

    peer2->peer_s.peer = peer1;
    peer2->peer_s.read_pipe = curpipe2;
    peer2->peer_s.write_pipe = curpipe1;

	req->admitted =1;
//wakes up socket that called connect
	kernel_signal(&req->connected_cv);
	socket->refcount--;

	return p1;
}


int sys_Connect(Fid_t sock, port_t port, timeout_t timeout)
{
	FCB *curr = get_fcb(sock);
	if(curr == NULL){
		return -1;
	}

	socket_cb *socket = curr->streamobj;
	//not legal
	if(socket == NULL || socket->type!=SOCKET_UNBOUND) return -1;
	//ilegal port
	if(port<0 || port>MAX_PORT) return -1;

	socket_cb *listener = PORT_MAP[port];
	//no listener socket bound on given port
	if(listener == NULL) return -1;

	socket->refcount++;
	//create the request 
	connection_request* connect = (connection_request*)xmalloc(sizeof(connection_request));

	connect->admitted=0;
	connect->peer = socket;
	connect->connected_cv = COND_INIT;
	rlnode_init(&connect->queue_node,connect);
	//insert request in accept queue
	rlist_push_back(&listener->listener_s.queue,&connect->queue_node);
	//wakes up request
	kernel_signal(&listener->listener_s.req_available);
	//timeout expire
	if(kernel_timedwait(&connect->connected_cv,SCHED_PIPE,timeout)==0){
		return -1;
	}

	free(connect);
	

	if(socket->refcount==0) {
		free(socket);
		return -1;
	}
	else{
		socket->refcount--;
		if(connect->admitted==0) {
			return -1;
		}else {
			return 0;
		}
	}

}


int sys_ShutDown(Fid_t sock, shutdown_mode how)
{
	FCB* fcb = get_fcb(sock);
	if(fcb==NULL) return -1;

	socket_cb* socket = (socket_cb*) fcb->streamobj;
	if(socket->type!=SOCKET_PEER) return -1;

	switch(how) {
		case SHUTDOWN_READ:
		if(socket->peer_s.read_pipe !=NULL) {
			pipe_reader_close(socket->peer_s.read_pipe);
			socket->peer_s.read_pipe=NULL;
			
		}
		break;
		case SHUTDOWN_WRITE:
		if(socket->peer_s.write_pipe !=NULL) {
			pipe_writer_close(socket->peer_s.write_pipe);
			socket->peer_s.write_pipe=NULL;

		}
		break;
		case SHUTDOWN_BOTH:
		if(socket->peer_s.read_pipe !=NULL) {
			pipe_reader_close(socket->peer_s.read_pipe);
			socket->peer_s.read_pipe=NULL;
			
		}
		if(socket->peer_s.write_pipe !=NULL) {
			pipe_writer_close(socket->peer_s.write_pipe);
			socket->peer_s.write_pipe=NULL;
		
		}
		break;
		default:
		return -1;
		break;
	}

	return 0;
}