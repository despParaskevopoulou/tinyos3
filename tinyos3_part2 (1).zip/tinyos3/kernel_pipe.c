#include "tinyos.h"
#include "kernel_streams.h"
#include "kernel_dev.h"
#include "kernel_cc.h"



int error_read(void* pipecb, char *buf, unsigned int size)
{
	return -1;
}

int error_write(void* pipecb, const char *buf, unsigned int size)
{
	return -1;
}

//
int pipe_read(void* pipecb, char *buf, unsigned int size)
{
    pipe_cb* curr_pipe = (pipe_cb*) pipecb;
    int read = 0;
    //fid doesn't exist or FCB reader doesn't exist
    if(curr_pipe == NULL || curr_pipe->reader == NULL){
        return -1;
    }

    //pipe buffer is empty
    while(curr_pipe->w_pos==curr_pipe->r_pos && curr_pipe->writer != NULL) 
    {   
        //sleep
        kernel_wait(&curr_pipe->has_data, SCHED_PIPE);
    }

       while((curr_pipe->r_pos != curr_pipe->w_pos) && read<size)
    {

        buf[read] = curr_pipe->BUFFER[curr_pipe->r_pos];
        curr_pipe->numOfDataRead++;
        read++;
        curr_pipe->r_pos++;
        if(curr_pipe->r_pos >= PIPE_BUFFER_SIZE)
        {
            curr_pipe->r_pos = 0;
        }
    }
//if data read is equal to size means that all the data is read and we count again from 0 

    if(curr_pipe->numOfDataRead == size){
        curr_pipe->numOfDataRead = 0;
    }
//wakes up Writers 
    kernel_broadcast(&curr_pipe->has_space);
    //number of data read
	return read;
}

int pipe_write(void* pipecb, const char *buf, unsigned int size)
{
    pipe_cb* curr_pipe = (pipe_cb*) pipecb;
    int written = 0;
   //fid doesn't exist or FCB reader/writer doesn't exist
    if(curr_pipe == NULL || curr_pipe->writer == NULL || curr_pipe->reader == NULL){
        return -1;
    }
    while((curr_pipe->w_pos+1)%PIPE_BUFFER_SIZE == curr_pipe->r_pos && curr_pipe->reader != NULL) //pipe buffer is full
    {   
        //sleep 
        kernel_wait(&curr_pipe->has_space, SCHED_PIPE);
    }

/*check if read end closed while waiting*/
    if(curr_pipe->reader == NULL)
    {
        return -1;  
    }

    while(((curr_pipe->w_pos+1)%PIPE_BUFFER_SIZE != curr_pipe->r_pos) && written<size)
    {
        curr_pipe->BUFFER[curr_pipe->w_pos] = buf[written];
        curr_pipe->numOfDataWritten++;
        written++;
        curr_pipe->w_pos++;

        if(curr_pipe->w_pos >= PIPE_BUFFER_SIZE)
        {
            curr_pipe->w_pos = 0;
        }
    }

    //check if the writer reached the size of the buffer so data is written again from the start of the buffer
    if(curr_pipe->numOfDataWritten == size-1){
        curr_pipe->numOfDataWritten = 0;
    }
//Wakes up readers
    kernel_broadcast(&curr_pipe->has_data);
	return written;
}

int pipe_reader_close(void* pipecb) 
{
    pipe_cb* curpipe = (pipe_cb*) pipecb;

    if(curpipe==NULL) 
        return -1;

    curpipe->reader = NULL;
    if(curpipe->writer==NULL){
        free(curpipe);
    }   
    return 0;
}

int pipe_writer_close(void* pipecb) 
{
    pipe_cb* curpipe = (pipe_cb*) pipecb;

    if(curpipe==NULL) return -1;

    curpipe->writer = NULL;
//Wakes up readers
    kernel_broadcast(&curpipe->has_data);

    if(curpipe->reader == NULL){
        free(curpipe);
    }
    return 0;
}



file_ops pipe_reader_ops = {
  //.Open = serial_open,
  .Read = pipe_read,
  .Write = error_write,
  .Close = pipe_reader_close
};

file_ops pipe_writer_ops = {
  //.Open = serial_open,
  .Read = error_read,
  .Write = pipe_write,
  .Close = pipe_writer_close
};

int sys_Pipe(pipe_t* pipe)
{
	Fid_t fid[2];
	FCB* fcb[2];
	if(!FCB_reserve(2, fid, fcb)){
		return -1;
	}
	pipe_cb* PIPE_CB =(pipe_cb*)xmalloc(sizeof(pipe_cb));

	PIPE_CB->reader = fcb[0];
	PIPE_CB->writer = fcb[1];

	PIPE_CB->has_space = COND_INIT;
	PIPE_CB->has_data = COND_INIT;
	PIPE_CB->w_pos = 0;
	PIPE_CB->r_pos = 0;
    PIPE_CB->numOfDataWritten = 0;
    PIPE_CB->numOfDataRead    = 0;
	
	fcb[0]->streamobj = PIPE_CB;
    fcb[0]->streamfunc = &pipe_reader_ops;

    fcb[1]->streamobj = PIPE_CB;
    fcb[1]->streamfunc = &pipe_writer_ops;

    pipe->read  = fid[0];
    pipe->write = fid[1];

    return 0;
}



