 #include "tinyos.h"
#include "kernel_dev.h"
#include "kernel_streams.h"

// @brief Socket type

enum socket_type{
	SOCKET_LISTENER,
	SOCKET_UNBOUND,
	SOCKET_PEER
};

typedef struct socket_control_block socket_cb;

// @brief listener socket

typedef struct listener_socket {
	rlnode queue;
	CondVar req_available;
} listener_socket;


// @brief unbound socket

typedef struct unbound_socket {
	rlnode unbound_socket;
} unbound_socket;

// @brief peer socket

typedef struct peer_socket {
	socket_cb* peer;
	pipe_cb* write_pipe;
	pipe_cb* read_pipe;

} peer_socket;

// @brief socket control block

typedef struct socket_control_block{
	uint refcount;
	FCB* fcb;
	Fid_t fid;
	enum socket_type type;
	port_t port;

	union {
		listener_socket listener_s;
		unbound_socket unbound_s;
		peer_socket peer_s;
	};
} socket_cb;


typedef struct connection_request {
	int admitted;
	socket_cb* peer;

	CondVar connected_cv;
	rlnode queue_node;

} connection_request;

socket_cb* PORT_MAP[MAX_PORT];

//int sys_Listen(Fid_t sock);
//Fid_t sys_Accept(Fid_t lsock);
//int sys_Connect(Fid_t sock, port_t port, timeout_t timeout);
//int sys_ShutDown(Fid_t sock, shutdown_mode how);
int socket_read(void* socket_cb_t, char *buf, unsigned int n);
int socket_write(void* socket_cb_t, const char *buf, unsigned int n);
int socket_close(void* socket_cb_t);